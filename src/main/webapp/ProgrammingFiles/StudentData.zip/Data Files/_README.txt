These Data Files are for the competitors' usage only. Input will come from standard input and NOT files.
Use input(), Scanner scanner = new Scanner(System.in), or std::cin instead